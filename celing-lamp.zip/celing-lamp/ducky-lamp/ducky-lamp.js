// DUCKY-LAMP | OpenJSCAD v2 | mm
// Reference-inspired flowing pendant shade; hidden dimensions are inferred.
// Separate parts fit a 250 x 250 x 250 mm printer. Bottom stays fully open.
// Use the numbered print selections. Assembled is preview only.
// Provisional holder bore: 42.5 mm. Measure your shade-ring holder first.
// Real certified holder/retaining rings and cord strain relief are required.
// LED only; no incandescent/halogen. Material/temperature/load tests required.
const {polyhedron,circle,rectangle} = require('@jscad/modeling').primitives;
const {union,subtract,intersect} = require('@jscad/modeling').booleans;
const {extrudeLinear} = require('@jscad/modeling').extrusions;
const {translate,rotateZ,rotateX} = require('@jscad/modeling').transforms;
const {generalize} = require('@jscad/modeling').modifiers;
const {measureBoundingBox} = require('@jscad/modeling').measurements;
const {colorize} = require('@jscad/modeling').colors;
function getParameterDefinitions() {
  return [
    {name:'part',type:'choice',initial:'01_spiral_shade',values:[
      '01_spiral_shade','02_internal_holder_adapter','03_vented_top_cover',
      '04_holder_fit_coupon','assembled'],caption:'Separate part / preview'},
    {name:'holderBore',type:'float',initial:42.5,caption:'Measured holder diameter + clearance (mm)'},
    {name:'wall',type:'float',initial:1.2,caption:'Main shade wall (1.2–2 mm)'},
    {name:'quality',type:'choice',initial:'print',values:['print','preview'],caption:'Mesh resolution'}
  ];
}
const H=190,FLUTES=84;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
const profile=[[0,84],[0.08,94],[0.2,101],[0.35,99],[0.52,90],
  [0.67,85],[0.80,70],[0.90,59],[0.95,53],[1,46]];
function baseRadius(t) {
  let i=0;while(i<profile.length-2&&t>profile[i+1][0])i++;
  const a=profile[i],b=profile[i+1],before=profile[Math.max(0,i-1)],
    after=profile[Math.min(profile.length-1,i+2)],dt=b[0]-a[0],u=(t-a[0])/dt;
  let ma=(b[1]-before[1])/(b[0]-before[0]);
  let mb=(after[1]-a[1])/(after[0]-a[0]);
  if(a[1]===b[1])ma=mb=0;
  
  return (2*u*u*u-3*u*u+1)*a[1]+(u*u*u-2*u*u+u)*dt*ma+
    (-2*u*u*u+3*u*u)*b[1]+(u*u*u-u*u)*dt*mb;
}
// Closed solid annular shell, with open passage through both ends.
function ringMesh(levels,segments,radii) {
  const points=[],faces=[],stride=segments*2;
  for(let j=0;j<=levels;j++) for(let side=0;side<2;side++)
    for(let k=0;k<segments;k++) {
      const a=2*Math.PI*k/segments,[outer,inner,z]=radii(j/levels,a);
      const r=side?inner:outer;points.push([r*Math.cos(a),r*Math.sin(a),z]);
    }
  for(let j=0;j<levels;j++) for(let k=0;k<segments;k++) {
    const q=(k+1)%segments,a=j*stride+k,b=j*stride+q,c=b+stride,d=a+stride;
    faces.push([a,b,c],[a,c,d]);
    faces.push([a+segments,d+segments,c+segments],[a+segments,c+segments,b+segments]);
  }
  for(let k=0;k<segments;k++) {
    const q=(k+1)%segments,top=levels*stride;
    faces.push([k,q+segments,q],[k,k+segments,q+segments]);
    faces.push([top+k,top+q,top+q+segments],[top+k,top+q+segments,top+k+segments]);
  }
  return polyhedron({points,faces,orientation:'outward'});
}
function shade(wall=1.2,preview=false) {
  return ringMesh(preview?152:304,preview?336:672,(t,a)=>{
    const z=t*H,neck=smooth((t-0.84)/0.09);
    const phase=100*Math.PI/180*smooth(t)-0.38;
    const broad=12.5*Math.pow(Math.sin(Math.PI*t),1.1)*(1-neck)*Math.cos(3*(a-phase));
    const fluteFade=(1-smooth((t-0.985)/0.015))*(0.65+0.35*smooth(t/0.04));
    const ridge=1.15*fluteFade*Math.pow((1+Math.cos(FLUTES*(a-phase)))/2,2);
    const base=baseRadius(t)+broad;
    const outer=base+ridge;
    let thickness=wall+(2-wall)*(1-smooth(t/0.045));
    thickness=thickness+(1.6-thickness)*neck;
    let inner=base-thickness;
    if(z>=H-12){const start=baseRadius((H-12)/H)-1.6;
      inner=start+(36-start)*clamp((z-(H-12))/12,0,1);}
    return [outer,inner,z];
  });
}
const disk=r=>circle({radius:r,segments:128});
const ring=(outer,inner)=>subtract(disk(outer),disk(inner));
const extrude=(g,h)=>extrudeLinear({height:h},g);
// Structured polar cells produce shared-edge meshes without boolean seams.
function polarCells(zs,radial,segments,filled) {
  const points=[],faces=[],nr=radial(zs[0]).length,nz=zs.length;
  const id=(k,r,j)=>(k*nr+r)*segments+(j+segments)%segments;
  for(const z of zs) for(const r of radial(z)) for(let j=0;j<segments;j++) {
    const a=2*Math.PI*j/segments;points.push([r*Math.cos(a),r*Math.sin(a),z]);
  }
  const occupied=(k,r,j)=>k>=0&&k<nz-1&&r>=0&&r<nr-1&&
    filled(k,r,(j+segments)%segments,segments);
  const quad=(a,b,c,d)=>faces.push([a,b,c],[a,c,d]);
  for(let k=0;k<nz-1;k++) for(let r=0;r<nr-1;r++) for(let j=0;j<segments;j++) {
    if(!occupied(k,r,j))continue;
    const a=id(k,r,j),b=id(k,r+1,j),c=id(k,r+1,j+1),d=id(k,r,j+1);
    const A=id(k+1,r,j),B=id(k+1,r+1,j),C=id(k+1,r+1,j+1),D=id(k+1,r,j+1);
    if(!occupied(k-1,r,j))quad(a,d,c,b);
    if(!occupied(k+1,r,j))quad(A,B,C,D);
    if(!occupied(k,r-1,j))quad(a,A,D,d);
    if(!occupied(k,r+1,j))quad(b,c,C,B);
    if(!occupied(k,r,j-1))quad(a,b,B,A);
    if(!occupied(k,r,j+1))quad(d,D,C,c);
  }
  return polyhedron({points,faces,orientation:'outward'});
}
function adapter(bore) {
  // Conical bearing supports shade from BELOW; real shade rings hold center.
  const start=baseRadius((H-12)/H)-1.6,slope=(start-36)/12;
  const radius=z=>start-slope*(z+0.2)-0.18;
  return polarCells([0,2.4,6],z=>[bore/2,28,radius(z)-2.4,radius(z)],128,
    (k,r,j,n)=>r===2||(k===0&&(r===0||Math.abs(Math.sin(4*Math.PI*(j+0.5)/n))<0.24)));
}
function cover(bore) {
  // Flat exterior face prints on bed. Locator upward; flip to install.
  return polarCells([0,1.6,3.1],()=>[bore/2,25.5,34.1,35.5,46],128,
    (k,r,j,n)=>k===1?r===2:(r!==1||Math.cos(16*Math.PI*(j+0.5)/n)>-0.4));
}
function clean(g) {
  const {geom3}=require('@jscad/modeling').geometries;
  try{geom3.validate(g);return g;}catch(_){}
  let out=generalize({snap:true,triangulate:true},g);
  try{geom3.validate(out);}catch(_){out=generalize({snap:true},generalize({triangulate:true},g));geom3.validate(out);}
  return out;
}
function main(p={}) {
  const bore=Number(p.holderBore)||42.5,wall=clamp(Number(p.wall)||1.2,1.2,2);
  if(bore<28||bore>46)throw new Error('Holder bore must be 28–46 mm; measure actual fitting.');
  const mode=p.part||'01_spiral_shade',preview=p.quality==='preview';
  let part;
  if(mode==='assembled') return [colorize([0.92,0.91,0.87],shade(wall,preview)),
    colorize([0.75,0.75,0.73],translate([0,0,H-11.8],clean(adapter(bore)))),
    colorize([0.92,0.91,0.87],translate([0,0,H+1.6],rotateX(Math.PI,clean(cover(bore)))))];
  if(mode==='01_spiral_shade')part=shade(wall,preview);
  else if(mode==='02_internal_holder_adapter')part=clean(adapter(bore));
  else if(mode==='03_vented_top_cover')part=clean(cover(bore));
  else if(mode==='04_holder_fit_coupon')part=clean(extrude(ring(bore/2+4,bore/2),1));
  else throw new Error('Unknown part selection.');
  const [lo,hi]=measureBoundingBox(part),size=hi.map((v,i)=>v-lo[i]);
  if(size[0]>240||size[1]>240||size[2]>250)throw new Error('Model exceeds printer clearance.');
  return translate([125-(hi[0]+lo[0])/2,125-(hi[1]+lo[1])/2,-lo[2]],part);
}
module.exports={main,getParameterDefinitions};
