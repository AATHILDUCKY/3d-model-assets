// AURORA REFERENCE v5 | OpenJSCAD v2 | millimetres
// Single-photo approximation:
// broad spiral lobes, dense flutes, flat rims.
//
// PRINT: narrow mounting end down.
// Preview modes are NOT print layouts.
//
// Commercial holder, retaining rings, cable, strain relief and ceiling
// mount are required. Printed canopy/sleeve/beads are cosmetic.
//
// LED only; verify bulb clearance and operating temperature.
//
// Slicer starting point:
// 0.4 mm nozzle, 0.42 mm line width, 0.24 mm layers.
// 2 walls, 5 top/bottom layers, 0% infill, vase mode OFF.
// Inspect thin walls, overhangs and mounting plate in slicer preview.

const { polyhedron, cylinder } =
  require('@jscad/modeling').primitives;

const { translate, rotateX, rotateZ } =
  require('@jscad/modeling').transforms;

const { colorize } =
  require('@jscad/modeling').colors;

const { measureVolume } =
  require('@jscad/modeling').measurements;

const PI = Math.PI;
const TAU = 2 * PI;

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

const smooth = x => {
  x = clamp(x, 0, 1);
  return x * x * (3 - 2 * x);
};

const IVORY = [0.94, 0.93, 0.89];
const BLACK = [0.10, 0.11, 0.12];

function getParameterDefinitions() {
  const f = (name, initial, caption) => ({
    name, type: 'float', initial, caption
  });

  const i = (name, initial, caption) => ({
    name, type: 'int', initial, caption
  });

  const choice = (name, initial, values, caption) => ({
    name, type: 'choice', initial, values, caption
  });

  return [
    choice(
      'part',
      'shade',
      [
        'shade', 'plate', 'kit', 'canopy', 'spacer',
        'sleeve', 'bead', 'fitRing',
        'assembled', 'exploded', 'angles'
      ],
      'Part / view'
    ),

    choice(
      'style',
      'fluted',
      ['fluted', 'silk', 'minimal'],
      'Surface finish'
    ),

    f('height', 155, 'Shade height mm'),
    f('diameter', 195, 'Diameter envelope mm'),
    f('neckDiameter', 76, 'Flat mounting-end diameter mm'),

    f('wall', 0.84, 'Nominal shell thickness mm'),

    i('lobes', 3, 'Broad spiral lobes'),
    f('lobeDepth', 18, 'Broad lobe depth mm'),
    f('twist', 85, 'Spiral rotation DEGREES'),

    i('ribs', 84, 'Fine flute count'),
    f('ribDepth', 0.65, 'Fine flute amplitude mm'),

    f('hemWave', 0, 'Lower-rim wave mm: 0 matches flat reference'),
    f('hemFade', 32, 'Rim-wave blend distance mm'),

    f(
      'holeDiameter',
      45,
      'Actual holder hole INCLUDING clearance mm'
    ),

    f('mountThickness', 2.4, 'Integral mounting plate thickness mm'),
    f('spacerHeight', 1.2, 'Optional holder spacer thickness mm'),

    f(
      'sleeveID',
      12,
      'Cosmetic cable-sleeve bore mm: measure fitting'
    ),

    f('sleeveHeight', 14, 'Cosmetic cable-sleeve height mm'),

    f('canopyDiameter', 76, 'Decorative canopy diameter mm'),
    f('canopyHeight', 26, 'Decorative canopy height mm'),

    f('cordDiameter', 6, 'Actual cord diameter mm'),
    i('beadCount', 0, 'Optional cord beads: 0-3'),

    f('bedSize', 250, 'Square print bed mm'),
    f('viewAngle', -20, 'Assembly viewing rotation DEGREES'),

    choice(
      'quality',
      'normal',
      ['draft', 'normal', 'high'],
      'Mesh quality; does not set printer speed'
    ),

    {
      name: 'report',
      type: 'checkbox',
      checked: true,
      caption: 'Log geometry and angle report'
    }
  ];
}

function config(p = {}) {
  const c = {};

  for (const d of getParameterDefinitions()) {
    c[d.name] = p[d.name] === undefined
      ? (d.type === 'checkbox' ? d.checked : d.initial)
      : p[d.name];

    if (d.type === 'float' || d.type === 'int') {
      c[d.name] = Number(c[d.name]);

      if (!Number.isFinite(c[d.name])) {
        throw Error(d.name + ' must be numeric');
      }

      if (d.type === 'int') {
        c[d.name] = Math.round(c[d.name]);
      }
    }

    if (d.values && !d.values.includes(c[d.name])) {
      throw Error('Unknown ' + d.name);
    }
  }

  const ranges = {
    height: [130, 220],
    diameter: [150, 220],
    neckDiameter: [60, 95],
    wall: [0.8, 1.2],

    lobes: [3, 6],
    lobeDepth: [0, 20],
    twist: [0, 110],
    ribs: [0, 120],
    ribDepth: [0, 0.9],

    hemWave: [0, 4],
    hemFade: [24, 50],

    holeDiameter: [28, 48],
    mountThickness: [1.8, 3.2],
    spacerHeight: [0.8, 4],

    sleeveID: [12, 45],
    sleeveHeight: [8, 25],

    canopyDiameter: [60, 90],
    canopyHeight: [20, 40],

    cordDiameter: [4, 8],
    beadCount: [0, 3],

    bedSize: [150, 400],
    viewAngle: [-180, 180]
  };

  for (const [k, [lo, hi]] of Object.entries(ranges)) {
    if (c[k] < lo || c[k] > hi) {
      throw Error(k + ' must be ' + lo + ' to ' + hi);
    }
  }

  if (c.ribs > 0 && c.ribs < 24) {
    throw Error('Use 0 ribs or at least 24');
  }

  c.texture = c.style === 'minimal' || !c.ribs
    ? 0
    : c.ribDepth * (c.style === 'silk' ? 0.35 : 1);

  c.neck = c.neckDiameter / 2;

  c.peak =
    c.diameter / 2 -
    c.lobeDepth -
    c.texture;

  if (c.peak < c.neck + 12) {
    throw Error('Increase diameter or reduce neck/lobe depth');
  }

  if (c.neck < c.holeDiameter / 2 + 7) {
    throw Error('Mounting plate needs 7 mm radial width');
  }

  c.twistRad = c.twist * PI / 180;

  const q = ['draft', 'normal', 'high'].indexOf(c.quality);

  c.n = Math.max(
    [180, 240, 360][q],
    c.texture ? c.ribs * [6, 8, 10][q] : 0
  );

  c.nz = Math.ceil(c.height / [2.2, 1.4, 0.9][q]);

  return c;
}

// The final ring MUST join the first ring.
// The previous v4.5 code omitted this closure.
function mesh(rings) {
  const n = rings[0].length;
  const points = rings.flat();
  const faces = [];

  for (let j = 0; j < rings.length; j++) {
    for (let i = 0; i < n; i++) {
      const k = (i + 1) % n;
      const next = (j + 1) % rings.length;

      const a = j * n + i;
      const b = j * n + k;
      const c = next * n + k;
      const d = next * n + i;

      faces.push([a, b, c], [a, c, d]);
    }
  }

  return polyhedron({
    points,
    faces,
    orientation: 'outward'
  });
}

function ring(r, z, n) {
  return Array.from({ length: n }, (_, i) => {
    const a = TAU * i / n;

    return [
      r * Math.cos(a),
      r * Math.sin(a),
      z
    ];
  });
}

const revolve = (profile, n = 128) =>
  mesh(profile.map(([r, z]) => ring(r, z, n)));

const phase = (c, t) => {
  const u = clamp(t / c.height, 0, 1);

  return c.twistRad * (
    0.65 * u +
    0.35 * smooth(u)
  );
};

// t is height in PRINT orientation:
// t=0 at neck, t=height at the open mouth.
function surface(c, t, a) {
  const u = clamp(t / c.height, 0, 1);
  const phi = a - phase(c, t);

  // The profile stays wide at the mouth instead of closing back down.
  const base =
    c.neck +
    (c.peak - c.neck) *
    Math.pow(Math.sin(PI * 0.65 * u), 1.2);

  const lobes =
    c.lobeDepth *
    smooth((t - 2) / 42) *
    (1 - 0.25 * smooth((u - 0.8) / 0.2)) *
    Math.cos(c.lobes * phi);

  // Flutes continue to the open rim.
  const texture =
    c.texture *
    smooth((t - 1) / 7) *
    Math.cos(c.ribs * phi);

  const relief =
    0.15 * (1 - smooth(t / 0.5));

  const wave =
    c.hemWave *
    smooth(
      (t - (c.height - c.hemFade)) / c.hemFade
    ) *
    Math.cos(c.lobes * phi);

  return {
    r: base + lobes + texture - relief,
    z: t + wave
  };
}

function thickness(c, t, a) {
  const e = 0.03;
  const da = 0.0002;

  const lo = Math.max(0, t - e);
  const hi = Math.min(c.height, t + e);

  const s = surface(c, t, a);

  const p = surface(c, hi, a);
  const m = surface(c, lo, a);

  const ap = surface(c, t, a + da);
  const am = surface(c, t, a - da);

  const rt = (p.r - m.r) / (hi - lo);
  const zt = (p.z - m.z) / (hi - lo);

  const ra = (ap.r - am.r) / (2 * da);
  const za = (ap.z - am.z) / (2 * da);

  if (zt < 0.25) {
    throw Error(
      'Rim wave folds the surface: reduce hemWave/twist'
    );
  }

  // Surface normal in cylindrical coordinates.
  // Includes the optional wavy rim.
  const nr = s.r * zt;
  const na = za * rt - ra * zt;
  const nz = -s.r * rt;

  const scale = Math.hypot(nr, na, nz) / nr;

  const edge =
    1 + 0.12 * smooth(
      (t - (c.height - 2.5)) / 2.5
    );

  // First-order normal-thickness approximation.
  return c.wall * edge * scale;
}

function shade(c) {
  const levels = [
    0,
    0.5,
    c.mountThickness
  ];

  for (let j = 1; j <= c.nz; j++) {
    const t = c.height * j / c.nz;

    if (t > c.mountThickness + 0.001) {
      levels.push(t);
    }
  }

  levels.sort((a, b) => a - b);

  const surfaceRing = (t, inside) =>
    Array.from({ length: c.n }, (_, i) => {
      // Align vertices with the helix.
      // This avoids jagged flute interpolation between height levels.
      const a =
        TAU * i / c.n +
        phase(c, t);

      const s = surface(c, t, a);

      const r =
        s.r -
        (inside ? thickness(c, t, a) : 0);

      if (r <= c.holeDiameter / 2 + 0.5) {
        throw Error(
          'Inner surface too close to holder opening'
        );
      }

      return [
        r * Math.cos(a),
        r * Math.sin(a),
        s.z
      ];
    });

  const rings = levels.map(t => surfaceRing(t, false));

  for (let j = levels.length - 1; j >= 0; j--) {
    if (levels[j] >= c.mountThickness) {
      rings.push(surfaceRing(levels[j], true));
    }
  }

  const h = c.holeDiameter / 2;

  // Integral mounting web and lightly relieved holder opening.
  rings.push(
    ring(h, c.mountThickness, c.n),
    ring(h, 0.25, c.n),
    ring(h + 0.25, 0, c.n)
  );

  return mesh(rings);
}

function canopy(c) {
  // Decorative cover only.
  // Print small annular face down, open end up.
  const R = c.canopyDiameter / 2;
  const H = c.canopyHeight;
  const t = 1.2;

  const b = Math.max(15, R - H + 2);
  const h = c.cordDiameter / 2 + 0.6;

  const w = t * Math.sqrt(
    1 + ((R - b) / (H - 2)) ** 2
  );

  return revolve([
    [b, 0],
    [b, 2],
    [R, H],
    [R - w, H],
    [b - w, 2],
    [h, 2],
    [h, 0]
  ]);
}

function spacer(c, test = false) {
  // Fit test matches the shade bore.
  // Optional spacer adds 0.2 mm diametral clearance.
  const h =
    c.holeDiameter / 2 +
    (test ? 0 : 0.1);

  const H = test
    ? c.mountThickness
    : c.spacerHeight;

  return revolve([
    [h + 6, 0],
    [h + 6, H],
    [h, H],
    [h, 0.25],
    [h + 0.25, 0]
  ]);
}

function sleeve(c) {
  // Cosmetic open tube over measured EXISTING hardware.
  // Does not clamp or support the cable.
  const r = c.sleeveID / 2;
  const H = c.sleeveHeight;

  return revolve([
    [r + 1.2, 0],
    [r + 1.2, H],
    [r, H],
    [r, 0]
  ], 96);
}

function bead(c) {
  const h = c.cordDiameter / 2 + 0.5;
  const r = h + 1.2;

  return revolve([
    [r, 0],
    [r + 0.5, 1],
    [r + 0.5, 9],
    [r, 10],
    [h, 10],
    [h, 0]
  ], 64);
}

function normal(v) {
  const a = v[0];
  const b = v[1];
  const c = v[2];

  const x = b.map((n, i) => n - a[i]);
  const y = c.map((n, i) => n - a[i]);

  return [
    x[1] * y[2] - x[2] * y[1],
    x[2] * y[0] - x[0] * y[2],
    x[0] * y[1] - x[1] * y[0]
  ];
}

function analyze(g, c, paint = false) {
  let max = 0;
  let area = 0;
  let over45 = 0;
  let over55 = 0;

  for (const p of g.polygons) {
    const v = p.vertices;
    const n = normal(v);
    const A = Math.hypot(...n) / 2;

    // Exclude mounting web, bed face and mouth-closing edge.
    // This report concerns the inner and outer side surfaces.
    const side = v.every(vertex =>
      vertex[2] > c.mountThickness + 0.02 &&
      vertex[2] < c.height - c.hemWave - 0.05
    );

    // Downward-facing overhang angle from vertical:
    // vertical wall=0 degrees; horizontal underside=90 degrees.
    const angle = side && n[2] < 0
      ? Math.atan2(
          -n[2],
          Math.hypot(n[0], n[1])
        ) * 180 / PI
      : 0;

    if (side) {
      area += A;
      max = Math.max(max, angle);

      if (angle > 45) over45 += A;
      if (angle > 55) over55 += A;
    }

    if (paint) {
      p.color = !side
        ? [0.70, 0.73, 0.77]
        : angle > 55
          ? [0.90, 0.18, 0.13]
          : angle > 45
            ? [1, 0.58, 0.08]
            : [0.24, 0.70, 0.47];
    }
  }

  return {
    maxDownwardSideAngleDeg: +max.toFixed(1),

    sideAreaOver45Percent:
      +(100 * over45 / area).toFixed(2),

    sideAreaOver55Percent:
      +(100 * over55 / area).toFixed(2),

    solidVolumeCm3:
      +(measureVolume(g) / 1000).toFixed(2)
  };
}

function pack(c, includeShade) {
  const items = [];

  if (includeShade) {
    items.push({
      g: shade(c),
      r: c.diameter / 2,
      color: IVORY
    });
  }

  items.push({
    g: canopy(c),
    r: c.canopyDiameter / 2,
    color: IVORY
  });

  items.push({
    g: spacer(c),
    r: c.holeDiameter / 2 + 6.1,
    color: IVORY
  });

  items.push({
    g: sleeve(c),
    r: c.sleeveID / 2 + 1.2,
    color: BLACK
  });

  for (let i = 0; i < c.beadCount; i++) {
    items.push({
      g: bead(c),
      r: c.cordDiameter / 2 + 2.2,
      color: IVORY
    });
  }

  items.sort((a, b) => b.r - a.r);

  const placed = [];
  const parts = [];

  const edge = c.bedSize / 2 - 5;
  const gap = 6;

  // Conservative circular envelopes prevent overlapping parts.
  for (const item of items) {
    let spot = null;

    for (
      let y = -edge + item.r;
      y <= edge - item.r + 0.001 && !spot;
      y += 2
    ) {
      for (
        let x = -edge + item.r;
        x <= edge - item.r + 0.001;
        x += 2
      ) {
        const clear = placed.every(p =>
          Math.hypot(x - p.x, y - p.y) >=
          item.r + p.r + gap
        );

        if (clear) {
          spot = { x, y, r: item.r };
          break;
        }
      }
    }

    if (!spot) {
      throw Error(
        'Parts do not fit. Export shade and kit separately ' +
        'or increase bedSize.'
      );
    }

    placed.push(spot);

    parts.push(
      colorize(
        item.color,
        translate([spot.x, spot.y, 0], item.g)
      )
    );
  }

  return parts;
}

function preview(c, exploded) {
  const H = c.height;
  const gap = exploded ? 22 : 0;

  // Rotate the printable shade into hanging orientation.
  const out = [
    colorize(
      IVORY,
      translate(
        [0, 0, H],
        rotateX(PI, shade(c))
      )
    )
  ];

  // Optional spacer on the inside of the mounting web.
  out.push(
    colorize(
      IVORY,
      translate(
        [
          0,
          0,
          H - c.mountThickness - c.spacerHeight - gap
        ],
        spacer(c)
      )
    )
  );

  out.push(
    colorize(
      BLACK,
      translate(
        [0, 0, H + gap],
        sleeve(c)
      )
    )
  );

  const cordLength = 125;
  const top = H + c.sleeveHeight + cordLength + gap;

  out.push(
    colorize(
      IVORY,
      translate([0, 0, top], canopy(c))
    )
  );

  // Cable is a visual reference ONLY.
  // The commercial socket and retaining rings are not modeled.
  // Never export this assembly as a print layout.
  out.push(
    colorize(
      [0.7, 0.7, 0.7],
      translate(
        [0, 0, H + (top - H) / 2],
        cylinder({
          radius: c.cordDiameter / 2,
          height: top - H,
          segments: 32
        })
      )
    )
  );

  for (let i = 0; i < c.beadCount; i++) {
    out.push(
      colorize(
        IVORY,
        translate(
          [
            0,
            0,
            H + c.sleeveHeight + 20 + 16 * i + gap
          ],
          bead(c)
        )
      )
    );
  }

  return out.map(g =>
    rotateZ(c.viewAngle * PI / 180, g)
  );
}

function main(p = {}) {
  const c = config(p);

  if (c.part === 'assembled' || c.part === 'exploded') {
    return preview(c, c.part === 'exploded');
  }

  if (c.part === 'plate' || c.part === 'kit') {
    return pack(c, c.part === 'plate');
  }

  const builders = {
    shade,
    angles: shade,
    canopy,
    spacer,
    sleeve,
    bead,
    fitRing: c => spacer(c, true)
  };

  const g = builders[c.part](c);

  if (c.part === 'shade' || c.part === 'angles') {
    if (c.diameter + 10 > c.bedSize) {
      throw Error(
        'Shade envelope exceeds bed with 5 mm margins'
      );
    }

    const report = analyze(
      g,
      c,
      c.part === 'angles'
    );

    if (c.report) {
      console.log(
        'AURORA: ' + JSON.stringify(report)
      );
    }

    if (c.part === 'angles') {
      return g;
    }
  }

  return colorize(
    c.part === 'sleeve' ? BLACK : IVORY,
    g
  );
}

module.exports = {
  main,
  getParameterDefinitions
};
